# CAQE

This is a binary release of CAQE. It contains statically build binaries for both Linux and Mac.
This release is not able to certify, this will be again available later.
Check https://www.react.uni-saarland.de/tools/caqe/ for more information.
